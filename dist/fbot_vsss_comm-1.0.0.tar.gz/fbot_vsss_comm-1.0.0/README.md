# Fbot Vsss Comm

This is a public package created by the FBot team of the Federal University of Rio Grande (FURG), for the LARC competition. This is a open source package, feel free to use as you wish. Following there is a tutorial for using it and an explanation of how it works.

## Basic

 <!-- To start with after you `import` the package. -->